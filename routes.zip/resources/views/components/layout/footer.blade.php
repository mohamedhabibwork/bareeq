<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b>{{ __('main.version') }}</b> 1.0.0
    </div>
    @lang('main.copy_right', ['date' => date('Y'), 'config' => config('app.name')])
</footer>

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
