<x-layout.app>
    @include('dashboard::worker.datatable')
</x-layout.app>
