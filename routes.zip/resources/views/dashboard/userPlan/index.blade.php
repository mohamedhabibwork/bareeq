<x-layout.app>
    @include('dashboard::userPlan.datatable')
</x-layout.app>
