<x-layout.app>
    <br>
    <div>
        @include('dashboard::admin.datatable')
    </div>
</x-layout.app>
