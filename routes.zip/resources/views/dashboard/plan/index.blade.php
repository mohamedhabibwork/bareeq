<x-layout.app>
    @include('dashboard::plan.datatable')
</x-layout.app>
