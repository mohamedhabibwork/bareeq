<x-layout.app>
    @include('dashboard::car.datatable')
</x-layout.app>
