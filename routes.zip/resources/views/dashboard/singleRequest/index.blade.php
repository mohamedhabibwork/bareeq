<x-layout.app>
    @include('dashboard::singleRequest.datatable')
</x-layout.app>
