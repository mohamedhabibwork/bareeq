<x-layout.app>
    @include('dashboard::user.datatable')
</x-layout.app>
