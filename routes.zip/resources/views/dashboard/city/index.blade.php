<x-layout.app>
    @include('dashboard::city.datatable')
</x-layout.app>
