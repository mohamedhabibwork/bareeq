<x-layout.app>
    @include('dashboard::workerUser.datatable')
</x-layout.app>
