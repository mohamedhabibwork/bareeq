<img loading="lazy" src="{{ $icon }}" loading="lazy" alt="{{ $id }}" width="{{  $width ?? 100 }}"
     height="{{ $height ?? 100 }}"/>
